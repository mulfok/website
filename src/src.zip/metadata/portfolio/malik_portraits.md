---
title: malik_portraits
image: /src/assets/portfolio/malik_portraits.png
date: 2026-07-09
tags: pixel
---
